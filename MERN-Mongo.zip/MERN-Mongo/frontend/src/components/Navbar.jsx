import React from 'react'

const Navbar=()=> {
  return (
    
      <nav classname="navbar navbar-expand-lg bg-body-tertiary">
  <div classname="container-fluid">
    <a classname="navbar-brand" href="#">Navbar</a>
    <button classname="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span classname="navbar-toggler-icon"></span>
    </button>
    <div classname="collapse navbar-collapse" id="navbarNav">
      <ul classname="navbar-nav">
        <li classname="nav-item">
          <a classnamename="nav-link active" aria-current="page" href="#">MERN</a>
        </li>
        <li classname="nav-item">
          <link to ="/" classname="nav-link" >Create Post</link>
        </li>
        <li classname="nav-item">
          <link to="/all" classname="nav-link">All post</link>
        </li>
      
      </ul>
    </div>
  </div>
</nav>

  )
};
export default Navbar;
