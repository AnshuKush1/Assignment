const express=require("express");
const app=express();
const mongoose=require("mongoose");
const dotenv=require("dotnev");
dotenv.config();
//const User=require("./model/usermodel");
app.use(express.json());
const userouter=require("./Routers/UseRouter")
const cors=require("dotenv");

app.use(cors());


mongoose.connect(process.env.URL).
then(()=>{
    console.log("connected success");
    app.listen(process.env.PORT || 8000);
})
.catch((error)=>{
    console.log("error,error");
}) 


app.use("/api/user",userouter);